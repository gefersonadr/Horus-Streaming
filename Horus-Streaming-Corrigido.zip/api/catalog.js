
const videos = [
  {
    title: "Vídeo de Teste",
    file: "/videos/teste.mp4"
  }
];

export default videos;
