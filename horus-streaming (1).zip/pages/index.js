import VideoCard from '../components/VideoCard';
import videos from '../data/videos.json';

export default function Home() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Hórus Streaming</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {videos.map(video => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
}