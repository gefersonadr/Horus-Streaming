import { useRouter } from 'next/router';
import videos from '../../data/videos.json';
import VideoPlayer from '../../components/VideoPlayer';

export default function VideoPage() {
  const router = useRouter();
  const { id } = router.query;
  const video = videos.find(v => v.id === parseInt(id));

  if (!video) return <p>Vídeo não encontrado</p>;

  return (
    <div style={{ padding: '20px' }}>
      <h1>{video.title}</h1>
      <VideoPlayer url={video.videoUrl} />
    </div>
  );
}