import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Login() {
  const [username, setUsername] = useState('');
  const router = useRouter();

  const handleLogin = () => {
    localStorage.setItem('user', username);
    router.push('/');
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Login</h1>
      <input 
        placeholder="Usuário" 
        value={username} 
        onChange={(e) => setUsername(e.target.value)} 
      />
      <button onClick={handleLogin}>Entrar</button>
    </div>
  );
}