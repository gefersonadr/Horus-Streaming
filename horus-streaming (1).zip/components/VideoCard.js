import Link from 'next/link';

export default function VideoCard({ video }) {
  return (
    <div style={{ margin: '20px', textAlign: 'center' }}>
      <img src={video.thumbnail} alt={video.title} width="200" />
      <h3>{video.title}</h3>
      <Link href={`/video/${video.id}`}>Assistir</Link>
    </div>
  );
}