import ReactPlayer from 'react-player';

export default function VideoPlayer({ url }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
      <ReactPlayer url={url} controls width="720px" height="405px" />
    </div>
  );
}